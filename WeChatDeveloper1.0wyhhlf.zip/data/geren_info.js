var json = {
  headSrc: '../../../icon/headSrc.png',
  name: '时御',
  phone: '12345667891',
  number: '2017141412345',
  college: '计算机学院（软件学院）',
  email: '123456789@qq.com',
}

module.exports = {
  gerenInfoList: json,
}
