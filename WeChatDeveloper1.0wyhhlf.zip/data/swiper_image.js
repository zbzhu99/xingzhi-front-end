var json = [
  { imgSrc: '../../icon/jingling_changji.jpg' },
  { imgSrc: '../../icon/changgeng.jpg' },
  { imgSrc: '../../icon/guyun.jpg' },
]
module.exports = {
  swiperList: json,
}
