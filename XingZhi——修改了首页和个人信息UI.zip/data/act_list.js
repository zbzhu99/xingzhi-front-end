var actList = [{
    title: "拼图活动",
    image: "/icon/img1.jpg",
    state: 1,
    actId: 1, //用于catchtap跳转
  },
  {
    title: "捐赠秋衣",
    image: "/icon/img2.jpg",
    state: 2,
    actId: 2,
  },
  {
    title: "捐赠秋衣",
    image: "/icon/img3.jpg",
    state: 3,
    actId: 3,
  },
  {
    title: "拼图活动",
    image: "/icon/img1.jpg",
    state: 1,
    actId: 1, //用于catchtap跳转
  },
  {
    title: "捐赠秋衣",
    image: "/icon/img2.jpg",
    state: 2,
    actId: 2,
  },
]

module.exports = {
  actList: actList
}